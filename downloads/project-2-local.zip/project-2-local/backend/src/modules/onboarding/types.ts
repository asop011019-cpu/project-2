export type ClothingCategoryId = "menswear" | "womenswear";
export type PublicationStatus = "draft" | "published";
export type ImageFormat = "model_outfit" | "flat_lay" | "collage";
export type ResponseValue = "liked" | "disliked" | "skipped";
export type SessionStatus = "in_progress" | "completed";
export interface ClothingCategory {
  id: ClothingCategoryId;
  name: string;
  order: number;
}
export interface GenreGroup {
  id: string;
  categoryId: ClothingCategoryId;
  name: string;
  description: string;
  order: number;
}
export interface Style {
  id: string;
  categoryId: ClothingCategoryId;
  genreGroupId: string;
  name: string;
  description: string;
  order: number;
  publicationStatus: PublicationStatus;
  /** Independent from genre display order; existing exploration order is retained. */
  explorationOrder: number;
}
export interface StyleImage {
  id: string;
  styleId: string;
  categoryId: ClothingCategoryId;
  originalRef: string;
  thumbnailRef: string;
  alt: string;
  width: number;
  height: number;
  format: ImageFormat;
  isGenerated: boolean;
  order: number;
  sourceUrl: string | null;
  creator: string | null;
  usageStatus: "pending" | "allowed" | "revoked";
  publicationStatus: PublicationStatus;
  contentHash: string | null;
}
export interface PublicStyleImage {
  id: string;
  styleId: string;
  categoryId: ClothingCategoryId;
  originalUrl: string;
  thumbnailUrl: string;
  alt: string;
  width: number;
  height: number;
  format: ImageFormat;
  isGenerated: boolean;
  order: number;
  sourceUrl: string | null;
  creator: string;
  usageStatus: "allowed";
  publicationStatus: "published";
}
export interface CatalogSnapshot {
  version: number;
  categories: ClothingCategory[];
  genreGroups: GenreGroup[];
  styles: Style[];
  images: StyleImage[];
}
export interface StyleSummary extends Style {
  imageCount: number;
}
export interface StyleDetail extends StyleSummary {
  images: PublicStyleImage[];
}
export interface SessionRecord {
  id: string;
  tokenHash: string;
  selectedCategoryId: ClothingCategoryId | null;
  startedAt: string;
  updatedAt: string;
  expiresAt: string;
}
export interface CategorySession {
  sessionId: string;
  categoryId: ClothingCategoryId;
  catalogVersion: number;
  currentStyleId: string | null;
  status: SessionStatus;
  startedAt: string;
  updatedAt: string;
  completedAt: string | null;
}
export interface SnapshotStyle {
  styleId: string;
  position: number;
  withdrawnAt: string | null;
}
export interface StyleResponse {
  sessionId: string;
  categoryId: ClothingCategoryId;
  styleId: string;
  response: ResponseValue;
  updatedAt: string;
}
export interface ImagePreference {
  sessionId: string;
  categoryId: ClothingCategoryId;
  styleId: string;
  imageId: string;
  selected: boolean;
  updatedAt: string;
}
export type GenreVisitStatus = "unseen" | "viewed" | "skipped";
export interface GenreVisit {
  genreGroupId: string;
  position: number;
  status: GenreVisitStatus;
  updatedAt: string | null;
}
export interface PhotoExploration {
  currentGenreGroupId: string | null;
  genres: GenreVisit[];
}
export interface PhotoExplorationView extends PhotoExploration {
  progress: {
    currentIndex: number | null;
    completedCount: number;
    totalCount: number;
    canComplete: boolean;
  };
}
export interface SessionView {
  id: string;
  selectedCategoryId: ClothingCategoryId | null;
  startedAt: string;
  updatedAt: string;
  expiresAt: string;
  status: SessionStatus;
  completedAt: string | null;
  contentStatus: "category_required" | "not_ready" | "ready";
  catalogVersion: number | null;
  currentCatalogVersion: number;
  catalogChanged: boolean;
  activeStyleOrder: string[];
  styles: StyleSummary[];
  currentStyleId: string | null;
  /** Null for existing style-response clients. Genre visits never imply preference. */
  photoExploration: PhotoExplorationView | null;
  progress: {
    currentIndex: number | null;
    answeredCount: number;
    totalCount: number;
    originalTotalCount: number;
    withdrawnCount: number;
    allAnswered: boolean;
    canComplete: boolean;
  };
  navigation: { previousStyleId: string | null; nextStyleId: string | null };
  responses: {
    styleId: string;
    response: ResponseValue | null;
    updatedAt: string | null;
  }[];
  imagePreferences: {
    styleId: string;
    imageId: string;
    selected: boolean;
    updatedAt: string;
  }[];
}
export interface SessionSummary {
  session: SessionView;
  likedStyles: StyleSummary[];
  dislikedStyles: StyleSummary[];
  skippedStyles: StyleSummary[];
  unansweredStyleIds: string[];
  likedImages: PublicStyleImage[];
  selectedExamples: {
    image: PublicStyleImage;
    style: { id: string; name: string; genreGroupId: string };
    genreGroup: { id: string; name: string };
  }[];
  isExploringOnly: boolean;
}
export interface CatalogView {
  version: number;
  contentStatus: "ready" | "not_ready";
  categories: ClothingCategory[];
  genreGroups: GenreGroupView[];
  styles: StyleSummary[];
}
export interface GenreGroupView extends GenreGroup {
  /** Taxonomy labels only; not-ready definitions are not exploration content. */
  styleDefinitions: {
    id: string;
    name: string;
    order: number;
    contentStatus: "ready" | "not_ready";
  }[];
  availableStyleCount: number;
  contentStatus: "ready" | "not_ready";
  representativeImage: PublicStyleImage | null;
}
export interface ApiErrorResponse {
  error: {
    code: string;
    message: string;
    issues?: { path: string; message: string }[];
  };
  requestId: string;
}
